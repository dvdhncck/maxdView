import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.zip.*;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.border.*;
import javax.swing.table.*;
//
//
public class SaveAsText implements ExprData.ExprDataObserver, Plugin
{

    public SaveAsText(maxdView mview_)
    {
	mview = mview_;
	edata = mview.getExprData();
	dplot = mview.getDataPlot();
    }

    public void startPlugin()
    {
	frame = new JFrame("Save As Text");
	
	frame.addWindowListener(new WindowAdapter() 
	    {
		public void windowClosing(WindowEvent e)
		{
		    cleanUp();
		}
	    });

	export_panel = new JPanel();
	export_panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	frame.getContentPane().add(export_panel, BorderLayout.CENTER);
	GridBagLayout gridbag = new GridBagLayout();
	export_panel.setPreferredSize(new Dimension(700, 400));
	export_panel.setLayout(gridbag);

	JSplitPane jsp_inner = new JSplitPane();
	jsp_inner.setOneTouchExpandable(true);
	JSplitPane jsp_outer = new JSplitPane();
	jsp_outer.setOneTouchExpandable(true);

	// analyseColumnWidths();

	Color title_colour = new JLabel().getForeground().brighter();	    
	int line = 0;

	{
	    line = 0;

	    JPanel bitpanel = new JPanel();
	    
	    TitledBorder title = BorderFactory.createTitledBorder(" Choose Options ");
	    
	    title.setTitleColor(title_colour);
	    bitpanel.setBorder(title);
	    
	    GridBagLayout bitbag = new GridBagLayout();
	    bitpanel.setLayout(bitbag);

	    JLabel label;
	    GridBagConstraints c;

	    label = new JLabel("Delimiter  ");
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.weighty = 1.0;
	    c.anchor = GridBagConstraints.EAST;
	    bitbag.setConstraints(label, c);
	    bitpanel.add( label );


	    String[] delim_str = { "Tab", "Space", "Comma" };
	    delim_jcb = new JComboBox(delim_str);
	    delim_jcb.setSelectedIndex(mview.getIntProperty("saveastext.delim", 0));

	    delim_jcb.addActionListener(new ActionListener()
				       {
					   public void actionPerformed(ActionEvent e) 
					   {
					       updateSample();
					   }
				       });

	    //jcb.setSelectedIndex( edata.getMeasurementDataType(s) );
	    //jcb.addActionListener(new SetDataTypeListener(s) );

	    delim_jcb.setToolTipText("Which character to put between columns");

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.anchor = GridBagConstraints.WEST;
	    c.weightx = 1.0;
	    bitbag.setConstraints(delim_jcb, c);
	    bitpanel.add(delim_jcb);
	    
	    
	    line++;

	    label = new JLabel("Sig.Digits  ");
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.weighty = 1.0;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.EAST;
	    bitbag.setConstraints(label, c);
	    bitpanel.add(label);

	    
	    sig_dig_slider = new JSlider(0, 32, 6);
	    sig_dig_slider.setValue(mview.getIntProperty("saveastext.sig_digs", 6));
	    sig_dig_slider.addChangeListener(new ChangeListener()
					     {
						 public void stateChanged(ChangeEvent e) 
						 {
						     updateSample();
						 }
					     });
	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.WEST;
	    c.fill = GridBagConstraints.HORIZONTAL;
	    bitbag.setConstraints(sig_dig_slider, c);
	    bitpanel.add(sig_dig_slider);

	    line++;
	    
	    label = new JLabel("Missing value  ");
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.weighty = 1.0;
	    c.anchor = GridBagConstraints.EAST;
	    bitbag.setConstraints(label, c);
	    bitpanel.add( label );


	    blank_jtf = new JTextField(8);
	    blank_jtf.setText("");
	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.fill = GridBagConstraints.HORIZONTAL;
	    c.anchor = GridBagConstraints.WEST;
	    bitbag.setConstraints( blank_jtf, c );
	    bitpanel.add( blank_jtf );
	    blank_jtf.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e) 
		    {
			updateSample();
		    }
		});

	    line++;
	    
	    
	    

	/*
	{
	    format_jcb = new JCheckBox("Align columns");
	    format_jcb.setSelected(mview.getBooleanProperty("saveastext.align", true));
	    format_jcb.setSelected(true);
	    export_panel.add(format_jcb);
	    
	    format_jcb.addActionListener(new ActionListener()
					  {
					      public void actionPerformed(ActionEvent e) 
					      {
						  updateSample();
					      }
					  });

	    GridBagConstraints c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.NORTHWEST;
	    gridbag.setConstraints(format_jcb, c);
	}
	line++;
	*/

	    label = new JLabel("Column labels  ");
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.weighty = 1.0;
	    c.anchor = GridBagConstraints.EAST;
	    bitbag.setConstraints(label, c);
	    bitpanel.add( label );

	    meas_labels_jchkb = new JCheckBox("Include");
	    meas_labels_jchkb.setSelected(mview.getBooleanProperty("saveastext.meas_label_headings", true));

	    meas_labels_jchkb.addActionListener(new ActionListener()
					 {
					     public void actionPerformed(ActionEvent e) 
					     {
						 updateSample();
					     }
					 });

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.WEST;
	    bitbag.setConstraints(meas_labels_jchkb, c);
	    bitpanel.add(meas_labels_jchkb);
	    
	    line++;


	    tidy_col_names_jchkb = new JCheckBox("Remove whitespace");
	    tidy_col_names_jchkb.setSelected(mview.getBooleanProperty("saveastext.remove_whitespace", true));
	    tidy_col_names_jchkb.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e) 
		    {
			updateSample();
		    }
		});

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.NORTHWEST;
	    bitbag.setConstraints(tidy_col_names_jchkb, c);
	    bitpanel.add(tidy_col_names_jchkb);
	    
	    /*
	    meas_labels_jchkb = new JCheckBox("Include");
	    meas_labels_jchkb.setSelected(mview.getBooleanProperty("saveastext.measure_headings", true));

	    meas_labels_jchkb.addActionListener(new ActionListener()
					 {
					     public void actionPerformed(ActionEvent e) 
					     {
						 updateSample();
					     }
					 });

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.NORTHWEST;
	    bitbag.setConstraints(meas_labels_jchkb, c);
	    bitpanel.add(meas_labels_jchkb);
	    */

	    
	    line++;

	    
	    label = new JLabel("Spots  ");
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.weighty = 1.0;
	    c.anchor = GridBagConstraints.EAST;
	    bitbag.setConstraints(label, c);
	    bitpanel.add(label);
	    

	    apply_filter_jchkb = new JCheckBox("Apply filter");
	    apply_filter_jchkb.setSelected(mview.getBooleanProperty("saveastext.apply_filter", true));
				     
	    apply_filter_jchkb.addActionListener(new ActionListener()
					 {
					     public void actionPerformed(ActionEvent e) 
					     {
						 updateSample();
					     }
					 });

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.WEST;
	    bitbag.setConstraints(apply_filter_jchkb, c);
	    bitpanel.add(apply_filter_jchkb);
	    
	    
	    line++;

        /*
	    only_clusters_jchkb = new JCheckBox("Only include visible clusters");
	    only_clusters_jchkb.setSelected(mview.getBooleanProperty("saveastext.only_clusters", false));
	    
	    export_panel.add(only_clusters_jchkb);
	    
	    only_clusters_jchkb.addActionListener(new ActionListener()
					 {
					     public void actionPerformed(ActionEvent e) 
					     {
						 updateSample();
					     }
					 });

	    GridBagConstraints c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.NORTHWEST;
	    gridbag.setConstraints(only_clusters_jchkb, c);
	*/

	    label = new JLabel("Row labels  ");
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.weighty = 1.0;
	    c.anchor = GridBagConstraints.EAST;
	    bitbag.setConstraints(label, c);
	    bitpanel.add(label);
	    
	    spot_labels_nts = new NameTagSelector(mview, NameTagSelector.MULTIPLE_SELECTION);
	    spot_labels_nts.loadSelection("saveastext.spot_labels");
	    spot_labels_nts.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e) 
		    {
			updateSample();
		    }
		});

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.WEST;
	    bitbag.setConstraints(spot_labels_nts, c);
	    bitpanel.add(spot_labels_nts);
	    

	    line++;

	    tidy_row_names_jchkb = new JCheckBox("Remove whitespace");
	    tidy_row_names_jchkb.setSelected(mview.getBooleanProperty("saveastext.row_label_remove_whitespace", true));
	    tidy_row_names_jchkb.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e) 
		    {
			updateSample();
		    }
		});

	    c = new GridBagConstraints();
	    c.gridx = 1;
	    c.gridy = line;
	    c.weightx = 1.0;
	    c.anchor = GridBagConstraints.NORTHWEST;
	    bitbag.setConstraints(tidy_row_names_jchkb, c);
	    bitpanel.add(tidy_row_names_jchkb);
	   
	    
	    // - - - - - - - - - - - - - - - - - -  - - 

	    jsp_inner.setLeftComponent(  bitpanel );

	    /*
	    c = new GridBagConstraints();
	    c.weighty = 10.;
	    c.fill = GridBagConstraints.VERTICAL;
	    c.gridx = 0;
	    gridbag.setConstraints( bitpanel, c );
	    export_panel.add( bitpanel );
	    */
	    
	}

	{
	    JPanel bitpanel = new JPanel();
	    
	    TitledBorder title = BorderFactory.createTitledBorder(" Choose Columns ");
	    
	    title.setTitleColor(title_colour);
	    bitpanel.setBorder(title);
	    
	    GridBagLayout bitbag = new GridBagLayout();
	    bitpanel.setLayout(bitbag);

	    meas_list = new DragAndDropList();
			
	    meas_list.addListSelectionListener( new ListSelectionListener()
		{
		    public void valueChanged(ListSelectionEvent e) 
		    {
			updateSample();
		    }
		});

	    meas_list.setToolTipText("Which Measurements to include");

	    JScrollPane jsp = new JScrollPane(meas_list);

	    bitpanel.add(jsp);
	    
	    GridBagConstraints c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = 0;
	    c.anchor = GridBagConstraints.WEST;
	    c.weightx = 10.;
	    c.weighty = 10.;
	    c.fill = GridBagConstraints.BOTH;
	    bitbag.setConstraints(jsp, c);

	    include_spot_attrs_jchkb = new JCheckBox("Show Spot Attributes");
	    include_spot_attrs_jchkb.setFont(mview.getSmallFont());
	    
	    include_spot_attrs_jchkb.addActionListener(new ActionListener()
		{
		    public void actionPerformed(ActionEvent e) 
		    {
			populateList();
			updateSample();
		    }
		});
	    
	    
	    c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = 1;
	    c.anchor = GridBagConstraints.WEST;
	    bitbag.setConstraints(include_spot_attrs_jchkb, c);
	    bitpanel.add(include_spot_attrs_jchkb);

	 
	    jsp_inner.setRightComponent(  bitpanel );

	    /*
	    c = new GridBagConstraints();
	    c.weighty = 10.;
	    c.gridx = 1;
	    c.fill = GridBagConstraints.VERTICAL;
	    gridbag.setConstraints( bitpanel, c );
	    
	    export_panel.add( bitpanel );
	    */
	}


	{
	    JPanel bitpanel = new JPanel();
	    
	    TitledBorder title = BorderFactory.createTitledBorder(" Choose Layout ");
	    
	    title.setTitleColor(title_colour);
	    bitpanel.setBorder(title);
	    
	    GridBagLayout bitbag = new GridBagLayout();
	    bitpanel.setLayout(bitbag);

	    view_table = new JTable();
	    view_table.setBackground(export_panel.getBackground());
	    view_table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    view_table.setFont(mview.getSmallFont());
	    view_table.setRowSelectionAllowed(false);
	    view_table.setColumnSelectionAllowed(false);
	    view_table.setCellSelectionEnabled(false);
	    view_table.setDefaultEditor(String.class, null);

	    // embed the text viewer in a scroll pane
	    JScrollPane view_scroller = new JScrollPane(view_table);
	    GridBagConstraints c = new GridBagConstraints();
	    c.fill = GridBagConstraints.BOTH;
	    c.weighty = 10.;
	    c.weightx = 10.;
	    bitbag.setConstraints(view_scroller, c);
	    bitpanel.add(view_scroller);
	    

	    jsp_outer.setLeftComponent( jsp_inner );
	    jsp_outer.setRightComponent( bitpanel );
	    
	    c = new GridBagConstraints();
	    c.weightx = 10.;
	    c.weighty = 10.;
	    c.fill = GridBagConstraints.BOTH;
	    gridbag.setConstraints( jsp_outer, c );
	    export_panel.add( jsp_outer );	

	}
	
	{
	    JPanel buttons_panel = new JPanel();
	    GridBagLayout inner_gridbag = new GridBagLayout();
	    buttons_panel.setLayout(inner_gridbag);
	    buttons_panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 0, 0));

	    {
		compress_jchkb = new JCheckBox("Compress with GZIP");
		compress_jchkb.setSelected(mview.getBooleanProperty("saveastext.compress", true));
		
		compress_jchkb.addActionListener(new ActionListener() 
		    {
			public void actionPerformed(ActionEvent e) 
			{
			    // view_panel.scrollRectToVisible(new Rectangle(20,20));
			}
		    });
		
		
		buttons_panel.add(compress_jchkb);
		
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.anchor = GridBagConstraints.WEST;
		inner_gridbag.setConstraints(compress_jchkb, c);
	    }
	    {   
		final JButton jb = new JButton("Save");
		buttons_panel.add(jb);
		
		jb.setToolTipText("Ready to choose a filename...");
		
		jb.addActionListener(new ActionListener() 
				     {
					 public void actionPerformed(ActionEvent e) 
					 {
					     int returnVal = mview.getFileChooser().showSaveDialog(export_panel);
					     if (returnVal == JFileChooser.APPROVE_OPTION) 
					     {
						 File file = mview.getFileChooser().getSelectedFile();

						 // check whether file already exists....
						 if(file.exists())
						 {
						     if(mview.infoQuestion("File exists, overwrite?", "No", "Yes") == 0)
							 return;
						 }
						 
						 exportData(file);

						 // save all settings 
						 //
						 saveProps();
					     }
					 }
				     });
		
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 1;
		c.weightx = 1.0;
		c.anchor = GridBagConstraints.WEST;
		inner_gridbag.setConstraints(jb, c);
	    }
	    {   
		final JButton jb = new JButton("Help");
		buttons_panel.add(jb);
		
		jb.addActionListener(new ActionListener() 
				     {
					 public void actionPerformed(ActionEvent e) 
					 {
					     mview.getPluginHelpTopic("SaveAsText", "SaveAsText");
					 }
				     });
		
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 3;
		c.weightx = 1.0;
		c.anchor = GridBagConstraints.EAST;
		inner_gridbag.setConstraints(jb, c);
	    }
	    {   
		final JButton jb = new JButton("Close");
		buttons_panel.add(jb);
		
		jb.setToolTipText("Close this dialog...");
		
		jb.addActionListener(new ActionListener() 
				     {
					 public void actionPerformed(ActionEvent e) 
					 {
					     saveProps();
					     cleanUp();
					 }
				     });
		
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 4;
		c.anchor = GridBagConstraints.EAST;
		inner_gridbag.setConstraints(jb, c);
	    }
	    
	    export_panel.add(buttons_panel);
	    GridBagConstraints c = new GridBagConstraints();
	    c.gridx = 0;
	    c.gridy = line;
	    c.fill = GridBagConstraints.HORIZONTAL;
	    //c.gridwidth = 3;
	    c.weightx = 1.0;
	    gridbag.setConstraints(buttons_panel, c);

	}
	
	populateList(  );

	    
	updateSample();

	mview.getExprData().addObserver(this);

	frame.pack();
	frame.setVisible(true);
    }
    
    public void stopPlugin()
    {
	cleanUp();
    }


    public void cleanUp()
    {
	mview.getExprData().removeObserver(this);
	frame.setVisible(false);
    }

    public PluginInfo getPluginInfo()
    { 
	PluginInfo pinf = new PluginInfo("Save As Text", "exporter", 
							"Write data in a tabular ASCII format", "",
							1, 1, 0);
	return pinf;
    }

    private void saveProps()
    {
	mview.putIntProperty("saveastext.sig_digs", sig_dig_slider.getValue());
	mview.putIntProperty("saveastext.delim", delim_jcb.getSelectedIndex());
	// mview.putBooleanProperty("saveastext.align", format_jcb.isSelected());
	//mview.putIntProperty("saveastext.measures",meas_jcb.getSelectedIndex());
	mview.putBooleanProperty("saveastext.measure_headings",meas_labels_jchkb.isSelected());
	mview.putBooleanProperty("saveastext.apply_filter", apply_filter_jchkb.isSelected());
	spot_labels_nts.saveSelection("saveastext.spot_labels");
	mview.putBooleanProperty("saveastext.col_labels_remove_whitespace", tidy_col_names_jchkb.isSelected());
	mview.putBooleanProperty("saveastext.row_labels_remove_whitespace", tidy_row_names_jchkb.isSelected());
	//mview.putBooleanProperty("saveastext.spot_label_headings", spot_labels_jchkb.isSelected());
	mview.putBooleanProperty("saveastext.compress", compress_jchkb.isSelected());
    }
    
    public PluginCommand[] getPluginCommands()
    {
	PluginCommand[] com = new PluginCommand[3];
	
	String[] args = new String[] 
	{ 
	    // name                 // type           //default   // flag   // comment
	    "file",                 "file",           "",         "",       "destination file name",
	    "significant_digits",   "integer",        "10",       "",       "", 
	    "delimiter",            "string",         "tab",      "",       "one of 'tab', 'space' or 'comma'", 
	    "align_columns",        "boolean",        "false",    "",       "", 
	    "which_measurements",   "string",         "all",      "",       "either 'all' or 'currently enabled'", 
	    "measurement_headings", "boolean",        "true",     "",       "", 
	    "apply_filter",         "boolean",        "false",    "",       "", 
	    "spot_labels",          "name_tag_list",  "",         "",       "which Names or Name Attributes to include", 
	    "spot_label_headings",  "boolean",        "true",     "",       "include column headings for Names or Name Attributes", 
	    "tidy_row_labels",      "boolean",        "false",    "",       "replace spaces with underscores in row labels (i.e. Names or Name Attributes)", 
	    "tidy_column_labels",   "boolean",        "false",    "",       "replace spaces with underscores in column headings", 
	    "compress",             "boolean",        "false",    "",       "compress the output file with GZIP", 
	    "force_overwrite",      "boolean",        "false",    "",       "overwrite file of the same name if present",
	    "report_status",        "boolean",        "true",     "",       "show either success or failure message after saving"
	};
	
	//com[0] = new PluginCommand("start", "display the interface", null);
	//com[1] = new PluginCommand("set",  "set one or more parameters", args);
	//com[2] = new PluginCommand("save", "set one or more parameters then write file", args);
	
	com[0] = new PluginCommand("start", null);
	com[1] = new PluginCommand("set",   args);
	com[2] = new PluginCommand("save",  args);

	return com;
    }

    public void runCommand(String name, String[] args, CommandSignal done) 
    { 
	// 
	if(name.equals("start"))
	{
	    startPlugin();
	}

	
	if(name.equals("save") || name.equals("set"))
	{
	    if(frame == null)
		startPlugin();
	    
	    String dname = mview.getPluginStringArg("delimiter", args, "tab");

	    if(dname != null)
	    {
		dname = dname.toLowerCase();
		if(dname.equals("tab"))
		    delim_jcb.setSelectedIndex(0);
		if(dname.equals("space"))
		    delim_jcb.setSelectedIndex(1);
		if(dname.equals("comma"))
		    delim_jcb.setSelectedIndex(2);
	    }

	    /*
	    String mmode = mview.getPluginStringArg("which_measurements", args, "all");
	    if(mmode != null)
	    {
		mmode = mmode.toLowerCase();
		if(mmode.startsWith("currently enabled"))
		    meas_jcb.setSelectedIndex(0);
		if(mmode.startsWith("all"))
		    meas_jcb.setSelectedIndex(1);
	    }
	    */

	    ExprData.NameTagSelection nts = mview.getPluginNameTagSelectionArg("spot_labels", args, null);
	    if(nts != null)
		spot_labels_nts.setNameTagSelection( nts );

	    
	    //meas_labels_jchkb.setSelected( mview.getPluginBooleanArg("measurement_headings", args, true) );
	    
	    spot_labels_jchkb.setSelected( mview.getPluginBooleanArg("spot_label_headings", args, true) );

	    sig_dig_slider.setValue( mview.getPluginIntegerArg("significant_digits", args, 10) );
	    
	    apply_filter_jchkb.setSelected( mview.getPluginBooleanArg("apply_filter", args, false) );
	    
	    // format_jcb.setSelected( mview.getPluginBooleanArg("align_columns", args, false) );
	    
	    tidy_col_names_jchkb.setSelected( mview.getPluginBooleanArg("tidy_column_labels", args, false) );
	    tidy_row_names_jchkb.setSelected( mview.getPluginBooleanArg("tidy_row_labels", args, false) );

	    compress_jchkb.setSelected( mview.getPluginBooleanArg("compress", args, false) );

	    if(name.equals("save"))
	    {
		String fname = mview.getPluginStringArg("file", args, null);
		if(fname != null)
		{
		    report_status   =  mview.getPluginBooleanArg("report_status", args, true);
		    force_overwrite =  mview.getPluginBooleanArg("force_overwrite", args, false);
		    
		    File file = new File( fname );
		    exportData( file );
		}
		
		cleanUp();
	    }
	}

	if(done != null)
	    done.signal();
    } 

   //public String pluginType() { return "exporter"; }


    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- measurement ( & Spot attribute) list   --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  

    private class MeasSpotAttr
    {
	public MeasSpotAttr(int m_, int sa_, String l_) { m = m_; sa = sa_; label = l_; }
	public int m, sa;
	public String label;
    }

    private void populateList()
    {
	int count = 0;
	
	Vector res = new Vector();

	meas_list_index_to_data_ht = new Hashtable();

	for(int m=0; m < edata.getNumMeasurements(); m++)
	{
	    int m_id = edata.getMeasurementAtIndex(m);
	    res.addElement( edata.getMeasurementName( m_id ) );

	    meas_list_index_to_data_ht.put( new Integer( count++), 
					    new MeasSpotAttr( m_id, -1, edata.getMeasurementName( m_id ) ));

	    if(include_spot_attrs_jchkb.isSelected())
	    {
		ExprData.Measurement meas = edata.getMeasurement( m_id );
		
		for(int a=0; a < meas.getNumSpotAttributes(); a++)
		{
		    res.addElement( "  " + meas.getSpotAttributeName( a ) );

		    meas_list_index_to_data_ht.put( new Integer( count++), 
						    new MeasSpotAttr( m_id, a, meas.getSpotAttributeName( a ) ));
		}
	    }
	}

	meas_list.setListData( res );

    }

    
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  
    // --- --- ---   exportData()
    // --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  

    public void exportData(File file)
    {
	try
	{
	    BufferedWriter writer = null;

	    if(compress_jchkb.isSelected())
	    {
		// check for a .gz extension...
		String name = file.getPath();
		String new_name = new String(name);
		int ext_pos = name.lastIndexOf('.');
		if(ext_pos <= 0)
		{
		    new_name += ".gz";
		}
		else
		{
		    String ext = name.substring(ext_pos).toLowerCase();
		    if(ext.equals(".gz") || ext.equals(".zip"))
		    {
			new_name = name;
		    }
		    else
		    {
			new_name += ".gz";
		    }
		}
		//System.out.println("file renamed to " + new_name);

		if(!force_overwrite)
		{
		    if(file.exists())
		    {
			if(mview.infoQuestion("File exists, overwrite?", "No", "Yes") == 0)
			    return;
		    }
		}
						 

		file = new File(new_name);

		FileOutputStream fos = new FileOutputStream(file);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		GZIPOutputStream gos = new GZIPOutputStream(bos);
		OutputStreamWriter osw = new OutputStreamWriter(gos);
		writer = new BufferedWriter(osw);
	    }
	    else
	    {
		writer = new BufferedWriter(new FileWriter(file));
	    }

	    int lines = writeData(writer, -1);

	    writer.close();

	    if(report_status)
		mview.successMessage(lines + " lines written to " + file.getName());
	    
	    //System.out.println(lines + " lines written to " + file.getName());
	}
	catch (java.io.IOException ioe)
	{
	    mview.alertMessage("Unable to write\n"  + ioe);
	}
    }

    public void updateSample()
    {
	new SampleUpdater().start();
    }
    private class SampleUpdater extends Thread
    {
	public void run()
	{
	    //StringWriter sw = new StringWriter();
	    //BufferedWriter writer = new BufferedWriter(sw);

	    //	    int lines = writeData(sw, 20);

	    updateTable( 20 );

	    //int remain = (lines-20);
	    //if(remain > 0)
	    //sw.write("\n[ .." + ((remain==1) ? "one more line" : (remain + " more lines")) + ".. ]\n");


	    //System.out.println(lines  + " lines written to " + sw.toString());
	    
	    // view_panel.setText(sw.toString());
	    
	    // view_panel.scrollRectToVisible(new Rectangle(20,20));
	}
    }

    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  
    // --- --- ---  generate the actual text
    // --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    //
    // work out the maximum width of each column so everything can be suitably padded
    //
    private void analyseColumnWidths()
    {
	boolean skip;
	ExprData edata = mview.getExprData();

	// first, find the length of the longest number in each column
	//
	num_len = new int[edata.getNumMeasurements()];
	for(int m=0;m<edata.getNumMeasurements();m++)
	{
	   final int mi = edata.getMeasurementAtIndex(m);
		       
	   num_len[m] = edata.getMeasurementName(mi).length();
	   
	   for(int s=0;s<edata.getNumSpots();s++)
	   {
	       final int si = edata.getSpotAtIndex(s);
		
	       if((!use_filter) || (!edata.filter(si)))
	       {
		   final int len = String.valueOf(edata.eValueAtIndex(mi,si)).length();
	       
		   if(len > num_len[m])
		       num_len[m] = len;
	       }
	   }
	   num_len[m] += 1;
	}

	longest_name_len = 0;

	{
	    for(int s=0;s<edata.getNumSpots();s++)
	    {
		// if the filtering option is selected,
		// only examine spots
		//
		// .....
	    }
	}
    }

    public String tidyName(String n)
    {
	String t = n.trim();
	String r = t.replace('\t', '_');
	return r.replace(' ', '_');
    }



    // 
    //
    public Vector getLine(int line, ExprData.NameTagSelection nts)
    {
	Vector res = new Vector();

	final boolean tn = tidy_row_names_jchkb.isSelected();

	if(nts.getNames() != null)
	{
	    String[] names = nts.getFullNameTagArray(line);
		
	    
	    if(names != null)
	    {
		for(int n=0; n < names.length; n++)
		{
		    if(tn && (names[n] != null))
			names[n] = tidyName(names[n]);
		    
		    res.addElement( names[n] );
		}
	    }
	}
	
	final int sig_digs = sig_dig_slider.getValue();

	for(int m=meas_list.getMinSelectionIndex() ; m <= meas_list.getMaxSelectionIndex(); m++)
	{
	    if(meas_list.isSelectedIndex(m))
	    {
		MeasSpotAttr msa = (MeasSpotAttr) meas_list_index_to_data_ht.get( new Integer(m) );
			    
		String str;

		if(msa.sa >= 0)
		{
		    // TODO: trim to sig.digits if spot attr type == double
		    str = edata.getMeasurement(msa.m).getSpotAttributeDataValueAsString(msa.sa, line);
		}
		else
		{
		    double d = edata.eValue(msa.m,line);
		    if(Double.isNaN(d))
			str = blank_jtf.getText();
		    else
			str = mview.niceDouble(d, 100, sig_digs);
		}

		//if(tn && (str != null))
		//    str = tidyName(str);
		
		if(str == null)
		    str = blank_jtf.getText();

		res.addElement( str );
	    }
	}
	
	return res;
    }

    // 
    //
    public Vector getHeader(ExprData.NameTagSelection nts)
    {
	Vector res = new Vector();

	if(nts.getNames() != null)
	{
	    String[] attrs_names = nts.getNamesArray();

	    for(int n=0; n < attrs_names.length; n++)
	    {
		if(meas_labels_jchkb.isSelected())
		{
		    res.addElement(tidy_col_names_jchkb.isSelected() ? tidyName(attrs_names[n]) : attrs_names[n]);
		}
	    }
	}
	for(int m=meas_list.getMinSelectionIndex() ; m <= meas_list.getMaxSelectionIndex(); m++)
	{
	    if(meas_list.isSelectedIndex(m))
	    {
		MeasSpotAttr msa = (MeasSpotAttr) meas_list_index_to_data_ht.get( new Integer(m) );
		
		// check for spaces in the set name as it is written
		// and replace them with '_'s
		//
		
		String clean_name = msa.label;
		
		if(delim_jcb.getSelectedIndex() == 1)
		    clean_name = clean_name.replace(' ', '_');
		
		if(tidy_col_names_jchkb.isSelected())
		    clean_name = tidyName(clean_name);
		
		res.addElement(clean_name);
	    }
	}

	return res;
    }

    private int[] getColumnOrder( )
    {
	try
	{
	    TableColumnModel tcm = (TableColumnModel) view_table.getColumnModel();
	    TableModel        tm =       (TableModel) view_table.getModel();
	    
	    int[] order = new int[ tcm.getColumnCount() ];
	    for(int c=0; c < tcm.getColumnCount(); c++)
	    {
		//order[c] = tcm.getColumnIndexAtX(c);
		
		//order[c] = tcm.getColumnIndex( tcm.getColumn(c).getIdentifier() );
		
		int pos = tcm.getColumnIndex( tm.getColumnName(c) );
		
		//System.out.println( c + " = " + tm.getColumnName(c) + " -> " +  order[c] );
		
		order[ pos ] = c;
		
		//System.out.println( c + " : orig='" + 
		//		tm.getColumnName(c) + "' : actual='" +  
		//		tcm.getColumn(c).getIdentifier() + "'");
	    }
	    for(int o=0; o < order.length; o++)
		System.out.println( o + " : " + order[ o ] );
	    
	    return order;
	}
	catch(Exception ex)
	{
	    return null;
	}
    }

    private Vector reorderColumns( int[] order, Vector input )
    {
	Vector output = new Vector();

	for(int o=0; o < order.length; o++)
	{
	    output.addElement( input.elementAt( order[o] ));
	}

	return output;
    }

    // 
    //
    //public boolean hasHeader()
    //{
    //  // return (nts.getNames() != null);
    //}


    // 
    //
    public int updateTable(int max_lines)
    {
	
	//save the existing column ordering (if there is one)
	
	int[] current_order = getColumnOrder( );
	
	
	use_filter = apply_filter_jchkb.isSelected();
	
	Vector data = new Vector();

	ExprData.NameTagSelection nts = spot_labels_nts.getNameTagSelection();

	Vector line = null;

	if(meas_labels_jchkb.isSelected())
	    data.addElement( getHeader( nts ) );
	
	int l = 0;
	while((data.size() < max_lines) && (l < edata.getNumSpots()))
	{
	    final int si = edata.getSpotAtIndex(l);
	    
	    if((!use_filter) || (!edata.filter(si)))
	    {
		line = getLine(  si, nts );
		data.addElement( line );
	    }

	    if(data.size()==max_lines)
	    {
		if(line != null)
		{
		    Vector ftr = new Vector();
		    for(int f=0; f < line.size(); f++)
			ftr.addElement("...");
		    data.addElement(ftr);
		}
	    }

	    l++;
	}

	if(line != null)
	{
	    Vector hdr = new Vector();
	    for(int h=0; h < line.size(); h++)
		hdr.addElement( String.valueOf(h+1) );
	    
	    view_table.setModel( new DefaultTableModel( data, hdr ));

	    // re-install the previous column order
	    if(current_order != null)
	    {
		TableColumnModel tcm = (TableColumnModel) view_table.getColumnModel();
		TableModel        tm =       (TableModel) view_table.getModel();
 
		if(current_order.length == tcm.getColumnCount() )
		{
		    int iters = 0;
		    boolean correct = false;
		    while((iters < 10) && (!correct))
		    {
			correct = true;
			int[] order = getColumnOrder( );
			for(int o=0; o < order.length; o++)
			    if(order[o] != current_order[o])
				correct = false;

			if(!correct)
			{
			    System.out.println( "reordering...." + iters);
			    
			    for(int o=0; o < current_order.length; o++)
			    {
				
				// which column should be at this position ?
				
				System.out.println( current_order[ o ] + " -> " + o );
				
				int target = current_order[o];
				
				// where is this column now?
				
				int pos = tcm.getColumnIndex( tm.getColumnName(o) );
				
				// move it 
				
				tcm.moveColumn( pos, target );
			    }
			    
			    iters++;
			}
		    }
		}
	    }
	}

	return max_lines;
    }

    // write the data to a Writer 
    //
    public int writeData(Writer writer, int max_lines)
    {
	use_filter = apply_filter_jchkb.isSelected();
	
	ExprData.NameTagSelection nts = spot_labels_nts.getNameTagSelection();

	Vector line;
	int good_lines = 0;  // the actual number of lines that would be written ignoring 'max_lines'

	try
	{

	    int[] order = getColumnOrder();

	    char delim_char;
	    switch(delim_jcb.getSelectedIndex())
	    {
		case 0:
		    delim_char = '\t';
		    break;
	        case 1:
		    delim_char = ' ';
		    break;
	        default:
		     delim_char = ',';
		    break;
	    }

	    if(meas_labels_jchkb.isSelected())
	    {
		line = getHeader( nts );
		line = reorderColumns( order, line );
		for(int n=0; n < line.size(); n++)
		{
		    if(n > 0)
			writer.write(delim_char);

		    writer.write((String)line.elementAt(n));
		}
		writer.write('\n');
	    }

	    for(int l=0; l < edata.getNumSpots(); l++)
	    {
		final int si = edata.getSpotAtIndex(l);
		
		if((!use_filter) || (!edata.filter(si)))
		{
		    line = getLine(  si, nts );
		    line = reorderColumns( order, line );
		
		    for(int n=0; n < line.size(); n++)
		    {
			if(n > 0)
			    writer.write(delim_char);
			
			writer.write((String)line.elementAt(n));
		    }

		    good_lines++;
		    writer.write('\n');
		}
	    }
	}
	catch (java.io.IOException ioe)
	{
	    mview.alertMessage("Unable to write file\n\n" + ioe);
	}
	
	return good_lines;
	
    }


    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  
    // --- --- ---  observer 
    // --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // the observer interface of ExprData notifies us whenever something
    // interesting happens to the data as a result of somebody (including us) 
    // manipulating it
    //
    public void dataUpdate(ExprData.DataUpdateEvent due)
    {
	// analyseColumnWidths();
	updateSample();
    }

    public void measurementUpdate(ExprData.MeasurementUpdateEvent mue)
    {
	// analyseColumnWidths();
	updateSample();
    }

    public void clusterUpdate(ExprData.ClusterUpdateEvent cue)
    {
    }

    public void environmentUpdate(ExprData.EnvironmentUpdateEvent eue)
    {
    }

    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  
    // --- --- ---  stuff
    // --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    // --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  --- --- ---  
    private maxdView mview;
    private ExprData edata;
    private DataPlot dplot;

    private JPanel export_panel;
    // private JTextArea view_panel;
    private JSlider sig_dig_slider;

    private JFrame frame = null;

    private Hashtable meas_list_index_to_data_ht;

    private boolean use_filter = true;

    private JComboBox delim_jcb, spots_jcb;
    private NameTagSelector spot_labels_nts;
    private JCheckBox format_jcb, meas_labels_jchkb, spot_labels_jchkb;
    private JProgressBar export_progress;
    private JCheckBox compress_jchkb, apply_filter_jchkb, tidy_col_names_jchkb, tidy_row_names_jchkb;
    private DragAndDropList meas_list;
    private JCheckBox include_spot_attrs_jchkb;
    private JTable view_table;
    private boolean report_status   = true;
    private boolean force_overwrite = false;
    private JTextField blank_jtf;

    private int longest_name_len;
    private int[] num_len;
}
