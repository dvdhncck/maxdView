public class ArrayDescription
{
    public Instance[] features;
    
    public Instance[] reporters;   // note that there will be repeats in this array if there are replicates on the array
    public Instance[][] genes;     // note that there will be repeats in this array if there are replicates on the array

    // this is used to arrange the property values into a consistent order
    public java.util.Hashtable feature_id_to_index;
}
